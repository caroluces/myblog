function Card1(){
    alert("Hi carolina, kevin loves you   <3")
}


function Card2(){
    alert("You are amazing!!!")
}


function Card1(){
    alert("You are the best!!!")
}