function Card3(){
    console.log("Hi carolina, kevin loves you")
}