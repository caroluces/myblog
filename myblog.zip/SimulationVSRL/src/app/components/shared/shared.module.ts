import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimulationFormComponent } from '../simulation-form/simulation-form.component';
import { MainComponent } from '../simulation-form/main/main.component';
import { TitleComponent } from '../simulation-form/title/title.component';
import { FooterSimulatorComponent } from '../simulation-form/footer-simulator/footer-simulator.component';
import { LoginComponent } from '../simulation-form/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {  MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';


import { SalarioPageComponent } from '../simulation-form/salario-page/salario-page.component';
import { IvaComponent } from '../simulation-form/iva/iva.component';
import { AguinaldoComponent } from '../simulation-form/aguinaldo/aguinaldo.component';
import { PrimaComponent } from '../simulation-form/prima/prima.component';



@NgModule({
  
  declarations: [
    SimulationFormComponent,
    MainComponent,
    TitleComponent,
    FooterSimulatorComponent,
    LoginComponent,
    SalarioPageComponent,
    IvaComponent,
    AguinaldoComponent,
    PrimaComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule 
   
  ],
  exports:[
    SimulationFormComponent,
    MainComponent,
    TitleComponent,
    FooterSimulatorComponent,
    LoginComponent,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    SalarioPageComponent,
    IvaComponent,
    AguinaldoComponent,
    PrimaComponent
  ]
})
export class SharedModule { }
