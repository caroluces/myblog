export interface Parameter{
    sCodigo:any;
    sNombre:any;
    sValor:any;
    sTipo:any;
    sGrupo:any;
    sEstado:any;
    dtFechaHora:any;
    sUsuario:any;
}