import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Parameter } from './parameter';

@Injectable({
  providedIn: 'root'
})
export class ParametersService {

  parameters:Parameter[]
  constructor(private http: HttpClient) { }

  logo=null
  empresa=null
  titulo=null
  logoDH=null
  filasReportComparativo = null
  sidebarCollapse = false;
  autorizacionJefaturaRegional = null
  analistaDesarrolloHumano = null
  porcentajeIncremento = null
  dominicalHombre = null
  dominicalMujer = null
  SMN = null
  hrDominicalMujer = null
  hrDominicalHombre = null
  valorHrExtraMujer = null
  valorHrExtraHombre = null
  cantidadHrExtraMujer = null
  cantidadHrExtraHombre = null
  porcHrNocturnaMujer = null
  porcHrNocturnaHombre = null
  cantidadHrExtraDomingoMujer = null
  cantidadHrExtraDomingoHombre = null
  diasAnho = null
  diasMes = null
  porcAfp = null
  porcRciva = null
  notaRcivaPositiva = null
  notaRcivaNegativa = null
  bonoAntiguedad1 = null
  bonoAntiguedad2 = null
  bonoAntiguedad3 = null
  bonoAntiguedad4 = null
  bonoAntiguedad5 = null
  bonoAntiguedad6 = null
  bonoAntiguedad7 = null
  bonoAntiguedad8 = null

  static DateFormat = "dd-MM-yy"

  getLogo(data){
    this.logo=data
  }

  getEmpresa(data){
    this.empresa=data
  }

  getTitulo(data){
    this.titulo=data
  }

  getLogoDH(data){
    this.logoDH=data
  }

  setFilasReportComparativo(data){
    this.filasReportComparativo = data
  }

  getParameter(data): Observable<Parameter[]> {//endPoint
    var response=this.http.get<Parameter[]>(`${environment.urlLocal}parameter/byCodigo?code=`+data);
    return response;
  }

  

  getParameters(): Observable<Parameter[]> {//endPoint
    var response=this.http.get<Parameter[]>(`${environment.urlLocal}parameter`);
    return response;
  }
  
  setAutorizacionJefaturaRegional(data) {
    this.autorizacionJefaturaRegional = data
  }
  
  setAnalistaDesarrolloHumano(data) {
    this.analistaDesarrolloHumano= data
  }
  
  setDominicalHombre(data) {
    this.dominicalHombre= data
  }
  
  setDominicalMujer(data) {
    this.dominicalMujer= data
  }

  setPorcentajeIncremento(data) {
    this.porcentajeIncremento= data
  }

  setSMN (data){
    this.SMN = data
  }


  sethrDominicalMujer(data) {
    this.hrDominicalMujer= data
  }
  sethrDominicalHombre(data) {  this.hrDominicalHombre = data}
  setvalorHrExtraMujer(data) {  this.valorHrExtraMujer = data}
  setvalorHrExtraHombre(data) { this.valorHrExtraHombre = data}
  setcantidadHrExtraMujer(data) { this.cantidadHrExtraMujer = data}
  setcantidadHrExtraHombre(data) { this.cantidadHrExtraHombre = data}
  setporcHrNocturnaMujer(data) { this.porcHrNocturnaMujer = data}
  setporcHrNocturnaHombre(data) { this.porcHrNocturnaHombre = data }
  setcantidadHrExtraDomingoMujer(data) { this.cantidadHrExtraDomingoMujer = data}
  setcantidadHrExtraDomingoHombre(data) { this.cantidadHrExtraDomingoHombre = data}
  setdiasAnho(data) { this.diasAnho= data }
  setdiasMes(data) { this.diasMes = data}
  setporcAfp(data) { this.porcAfp = data}
  setporcRciva(data) {this.porcRciva = data}
  setnotaRcivaPositiva(data) { this.notaRcivaPositiva = data}
  setnotaRcivaNegativa(data) { this.notaRcivaNegativa = data}
  setBonoAntiguedad1(data) { this.bonoAntiguedad1 = data }
  setBonoAntiguedad2(data) { this.bonoAntiguedad2 = data }
  setBonoAntiguedad3(data) { this.bonoAntiguedad3 = data }
  setBonoAntiguedad4(data) { this.bonoAntiguedad4 = data }
  setBonoAntiguedad5(data) { this.bonoAntiguedad5 = data }
  setBonoAntiguedad6(data) { this.bonoAntiguedad6 = data }
  setBonoAntiguedad7(data) { this.bonoAntiguedad7 = data }
  setBonoAntiguedad8(data) { this.bonoAntiguedad8 = data }

  setSidebarCollapse(){
    this.sidebarCollapse = !this.sidebarCollapse
  }

}
