export const salarioLabels = {
    titulo_prima: 'SIMULACIÓN SALARIAL',
    logo: '/assets/images/images-simulator/img_calc.png',
    error_contrasena_longitud_minima: 'La contraseña debe contener mínimo 8 dígitos',
    error_contrasena_longitud_maxima: 'La contraseña debe contener mínimo 8 dígitos',
    recuerdame: 'Recuerdame',
    ingresar: 'Ingresar',
}