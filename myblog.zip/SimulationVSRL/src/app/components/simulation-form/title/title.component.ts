import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-title',
  templateUrl: './title.component.html',
  styleUrls: ['./title.component.css','/src/app/components/simulation-form/css/bootstrap.css','/src/app/components/simulation-form/css/custom_layout.css']
})
export class TitleComponent implements OnInit {

  TITULO="TU PUNTO DE CONSULTA"
  SUBTITULO="ATENCIÓN AL PERSONAL"
  LOGO="/assets/images/images-simulator/img_people.png"
  FECHA=new Date('MM/DD/YYYY');
  constructor(public serviceLogin:LoginService) { }

  ngOnInit(): void {
  }

}
