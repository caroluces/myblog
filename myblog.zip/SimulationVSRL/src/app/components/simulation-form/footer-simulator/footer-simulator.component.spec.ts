import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterSimulatorComponent } from './footer-simulator.component';

describe('FooterSimulatorComponent', () => {
  let component: FooterSimulatorComponent;
  let fixture: ComponentFixture<FooterSimulatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FooterSimulatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterSimulatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
