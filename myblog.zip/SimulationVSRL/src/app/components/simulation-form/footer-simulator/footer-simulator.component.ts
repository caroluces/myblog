import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-simulator',
  templateUrl: './footer-simulator.component.html',
  styleUrls: ['./footer-simulator.component.css']
})
export class FooterSimulatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
