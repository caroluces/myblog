import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimaComponent } from './prima/prima.component';
import { AguinaldoComponent } from './aguinaldo/aguinaldo.component';
import { IvaComponent } from './iva/iva.component';



@NgModule({
  declarations: [PrimaComponent, AguinaldoComponent, IvaComponent],
  imports: [
    CommonModule,
  ],
  exports:[],
 
})
export class SimulatorModule { }
