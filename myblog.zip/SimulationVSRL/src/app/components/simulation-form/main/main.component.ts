import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';
import { ParametersService } from '../../login/parameters.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css','/src/app/components/simulation-form/css/bootstrap.css','/src/app/components/simulation-form/css/custom_layout.css']
})
export class MainComponent implements OnInit {

  constructor(private router:Router,private serviceLoginOption:LoginService,private parameterService:ParametersService) { }

  ngOnInit(): void {
    this.parameterService.getParameters().subscribe(
      element=>{
        console.log(element)
        console.log("parametros")
        this.parameterService.getEmpresa(element.find(parameter => parameter.sCodigo === "EMPRESA")?.sValor)
        this.parameterService.getTitulo(element.find(parameter => parameter.sCodigo === "TITULO_CARTA")?.sValor)
        this.parameterService.getLogoDH(element.find(parameter => parameter.sCodigo === "LOGO_FORMULARIO_DH")?.sValor)
        this.parameterService.setAutorizacionJefaturaRegional(element.find(parameter => parameter.sCodigo === "AUTORIZACION_JEFATURA_REGIONAL")?.sValor)
        this.parameterService.setAnalistaDesarrolloHumano(element.find(parameter => parameter.sCodigo === "ANALISTA_DESARROLLO_HUMANO")?.sValor)
        this.parameterService.setPorcentajeIncremento(element.find(parameter => parameter.sCodigo === "PORCENTAJE_INCREMENTO")?.sValor)
        this.parameterService.setFilasReportComparativo(element.find(parameter => parameter.sCodigo === "CANTIDAD_FILAS_FORMULARIO")?.sValor)
        this.parameterService.getLogo(element.find(parameter => parameter.sCodigo === "LOGO")?.sValor)
        this.parameterService.setDominicalHombre(element.find(parameter => parameter.sCodigo === "DOMINICAL_MASCULINO")?.sValor)
        this.parameterService.setDominicalMujer(element.find(parameter => parameter.sCodigo === "DOMINICAL_FEMENINO")?.sValor)
        this.parameterService.setSMN(element.find(parameter => parameter.sCodigo === "SMN")?.sValor)

        this.parameterService.sethrDominicalMujer(element.find(parameter => parameter.sCodigo === "HR_DOMINICAL_FEMENINO")?.sValor) 
        this.parameterService.sethrDominicalHombre(element.find(parameter => parameter.sCodigo === "HR_DOMINICAL_MASCULINO")?.sValor) 
        this.parameterService.setvalorHrExtraMujer(element.find(parameter => parameter.sCodigo === "VALOR_HR_EXTRA_FEMENINO")?.sValor) 
        this.parameterService.setvalorHrExtraHombre(element.find(parameter => parameter.sCodigo === "VALOR_HR_EXTRA_MASCULINO")?.sValor) 
        this.parameterService.setcantidadHrExtraMujer(element.find(parameter => parameter.sCodigo === "CANTIDAD_HR_EXTRA_FEMENINO")?.sValor) 
        this.parameterService.setcantidadHrExtraHombre(element.find(parameter => parameter.sCodigo === "CANTIDAD_HR_EXTRA_MASCULINO")?.sValor) 
        this.parameterService.setporcHrNocturnaMujer(element.find(parameter => parameter.sCodigo === "%_HR_NOCTURNA_FEMENINO")?.sValor) 
        this.parameterService.setporcHrNocturnaHombre(element.find(parameter => parameter.sCodigo === "%_HR_NOCTURNA_MASCULINO")?.sValor) 
        this.parameterService.setcantidadHrExtraDomingoMujer(element.find(parameter => parameter.sCodigo === "CANTIDAD_HR_EXTRA_DOMINGO_FEMENINO")?.sValor) 
        this.parameterService.setcantidadHrExtraDomingoHombre(element.find(parameter => parameter.sCodigo === "CANTIDAD_HR_EXTRA_DOMINGO_MASCULINO")?.sValor) 
        this.parameterService.setdiasAnho(element.find(parameter => parameter.sCodigo === "DIAS_ANHO")?.sValor) 
        this.parameterService.setdiasMes(element.find(parameter => parameter.sCodigo === "DIAS_MES")?.sValor) 
        this.parameterService.setporcAfp(element.find(parameter => parameter.sCodigo === "%_AFP")?.sValor) 
        this.parameterService.setporcRciva(element.find(parameter => parameter.sCodigo === "%_RCIVA")?.sValor) 
        this.parameterService.setnotaRcivaPositiva(element.find(parameter => parameter.sCodigo === "NOTA_RCIVA_POSITIVA")?.sValor) 
        this.parameterService.setnotaRcivaNegativa(element.find(parameter => parameter.sCodigo === "NOTA_RCIVA_NEGATIVA")?.sValor) 

        this.parameterService.setBonoAntiguedad1(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD1")?.sValor) 
        this.parameterService.setBonoAntiguedad2(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD2")?.sValor) 
        this.parameterService.setBonoAntiguedad3(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD3")?.sValor) 
        this.parameterService.setBonoAntiguedad4(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD4")?.sValor) 
        this.parameterService.setBonoAntiguedad5(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD5")?.sValor) 
        this.parameterService.setBonoAntiguedad6(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD6")?.sValor) 
        this.parameterService.setBonoAntiguedad7(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD7")?.sValor) 
        this.parameterService.setBonoAntiguedad8(element.find(parameter => parameter.sCodigo === "BONOANTIGUEDAD8")?.sValor) 
        
        ParametersService.DateFormat = element.find(parameter => parameter.sCodigo === "FORMATO_FECHA")?.sValor
      });
  }


  onGoToPagePrima(){
    var session=localStorage.getItem('session')
   
    if(session=="1"){
      this.router.navigate(['/', 'simulatorPrima']);
    }else{
      this.serviceLoginOption.setOption('prima-page')
      this.router.navigate(['/', 'simulatorLogin']);
    }
  }
  onGoToPageSimuSal(){
    var session=localStorage.getItem('session')
   
    if(session=="1"){
      this.router.navigate(['/', 'simulatorSalarioPage']);
    }else{
      this.serviceLoginOption.setOption('simulatorSalarioPage')
      this.router.navigate(['/', 'simulatorLogin']);
    }
  }

}
