import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalarioPageComponent } from './salario-page.component';

describe('SalarioPageComponent', () => {
  let component: SalarioPageComponent;
  let fixture: ComponentFixture<SalarioPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalarioPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalarioPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
