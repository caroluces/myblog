import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulation-form',
  templateUrl: './simulation-form.component.html',
  styleUrls: ['./simulation-form.component.css','/src/app/components/simulation-form/css/bootstrap.css','/src/app/components/simulation-form/css/custom_layout.css'
 ]
})
export class SimulationFormComponent implements OnInit {

  _displayLogin=false
  constructor() { }

  ngOnInit(): void {
  }

  get displayMain(){
    return this._displayLogin;
  }

}
