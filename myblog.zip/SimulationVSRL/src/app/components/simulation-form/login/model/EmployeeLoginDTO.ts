export interface EmployeeLoginDTO{
    sCI:any;
    sPin:any;
}