import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EmployeeLoginDTO } from './model/EmployeeLoginDTO';
import { environment } from 'src/environments/environment';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  
  option=null
  TITULO="TU PUNTO DE CONSULTA"
  SUBTITULO="ATENCIÓN AL PERSONAL"
  LOGO="/assets/images/images-simulator/img_people.png"
  DISPLAY=false
  SEXO=''
  FECHA=""

  empleadoObj = null
  
  setOption(data){
    this.option=data
  }

  setHeaders(data){
    this.TITULO=data.sTitulo
    this.SUBTITULO=data.sNombre+ " "+ data.sApellido,
    this.LOGO=data.sLogo
    this.DISPLAY=true
    this.SEXO=data.sSexo
    this.FECHA=data.dfechaIngreso
    this.empleadoObj=data.empleadoObj
  }
  
  
  
  loginEmployee(data:EmployeeLoginDTO): Observable<Response>{
   return this.http.post(`${environment.urlLocal}employee/login`,data)
    .pipe(
      map((response:any)=>response)
    );
  }

}
