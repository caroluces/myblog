import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { salarioLabels } from '../../labels/salarioLabels';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css','/src/app/components/simulation-form/css/bootstrap.css','/src/app/components/simulation-form/css/custom_layout.css']
})
export class LoginComponent implements OnInit {

  
  form:FormGroup
  
  constructor(private fb:FormBuilder,private service:LoginService,private router:Router) { }

  ngOnInit(): void {
    this.buildForm()
  }

  buildForm(){
    this.form=this.fb.group({
      sCI:['',[Validators.required]],
      sPin:['',[Validators.required]]
    })

  }

  login(submit:FormGroup){
    var json={
      "sCI":submit.value.sCI,
      "sPin":submit.value.sPin
    }
    this.service.loginEmployee(json).subscribe(response=>{
      if(response['objModel']!==undefined && response['objModel']!==null){
        
        var jsonH={
          "sCI":submit.value.sCI,
          "sPin":submit.value.sPin,
          "sTitulo":salarioLabels.titulo_prima,
          "sLogo":salarioLabels.logo,
          "sNombre":response['objModel'].sNombre,
          "sApellido":response['objModel'].sApellido?response['objModel'].sApellido:'',
          "sSexo":response['objModel'].sSexo,
          "dfechaIngreso":response['objModel'].dfechaIngreso,
          "empleadoObj": response['objModel']
        }
        this.service.setHeaders(jsonH)
        this.router.navigate(['/', this.service.option]);
      }else{
        alert('Incorrect Credentials')
      }
    },
    error=>{
      alert('There are troubles')
    });
  }

}
