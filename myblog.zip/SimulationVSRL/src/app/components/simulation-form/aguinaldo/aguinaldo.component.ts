import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { LoginService } from '../login/login.service';
import { ParametersService } from '../../login/parameters.service';
import  { generalLabels } from '../../../labels/general-labels';
@Component({
  selector: 'app-aguinaldo',
  templateUrl: './aguinaldo.component.html',
  styleUrls: ['./aguinaldo.component.css']
})
export class AguinaldoComponent implements OnInit {
  generalLabel = generalLabels
  totalGanado = 0.00
  descuentosANS = 0.00
  basico =  new FormControl(0);
  domingos =  new FormControl('4');
  horasExtras =  new FormControl(0);
  horasNocturnas =  new FormControl(0);
  horasDomingo =  new FormControl(0);
  comisiones =  new FormControl(0);
  otros =  new FormControl(0);
  otrosIngresosIva = new FormControl(0);


  SMN = 2060
  empleado
  meses = ["NOV","DIC","ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC"]
  mesActual = 0
  anoActual = '0'
  dsctoAns = 0.00
  totalFacturasSalarioDelMes= 0.00
  totalPrimaPrima= 0.00
  deudecimas=0.00
  totalFacturasRciva = 0.00
  rcivaTotalPresentar = 0.0
  totalPrimaAguinaldo=0.0
  rciva = 0.00


  descuentoAFP =0.0
  ingresoNeto =0.0
  salariosMinimosx2 =0.0
  diferenciaAB =0.0
  impuestoDeterminado =0.0
  iva2SMN =0.0
  impuestoAPagar =0.0
  impuestoAPagarTotal =0.0
  totalFacturas = 0.0

  bonoAntiguedadActual = 0.0
  constructor(private service:LoginService,
    public parametersService:ParametersService) { }

  ngOnInit(): void {
    this.empleado = this.service.empleadoObj
    this.SMN = parseFloat(this.parametersService.SMN)
    this.mesActual = new Date().getMonth() + 2
    this.anoActual = new Date().getFullYear().toString().substr(-2)
    
    this.bonoAntiguedadActual=  this.getActualAntiguedad(this.empleado.nAntiguedadAnhos)

    this.deudecimas = this.empleado.nAntiguedadAnhos > 1  ? 12 : (this.empleado.nAntiguedadAnhos*this.parametersService.diasAnho)/ this.parametersService.diasMes 
      this.dsctoAns = (this.empleado.actualAmount > 13000 ? (this.empleado.actualAmount - 13000)*0.01 : 0) +  (this.empleado.actualAmount > 25000 ? (this.empleado.actualAmount - 25000)*0.05 : 0) + (this.empleado.actualAmount > 35000 ? (this.empleado.actualAmount - 35000)*0.1 : 0)
      this.totalFacturasSalarioDelMes = this.empleado.actualAmount - this.empleado.actualAmount* this.parametersService.porcAfp - this.dsctoAns - this.SMN*4;
      this.totalPrimaPrima =  (this.deudecimas >= 3) ? (((this.empleado.lastestAmount + this.empleado.penultimateAmount + this.empleado.antepenultimateAmount) / 3) / 12) * this.deudecimas : 0;
      this.totalFacturasRciva = Math.round(this.totalPrimaPrima + this.totalFacturasSalarioDelMes > 0 ? this.totalPrimaPrima + this.totalFacturasSalarioDelMes : 0)
      this.rciva = Math.round(this.totalFacturasRciva  > 0 ? this.totalFacturasRciva*this.parametersService.porcRciva : 0)
      this.rcivaTotalPresentar =  this.rciva - this.empleado.nRciva
      this.totalPrimaAguinaldo =  (this.deudecimas >= 3) ? (((this.empleado.bonusSep + this.empleado.bonusOct + this.empleado.bonusNov) / 3) / 12) * this.deudecimas : 0;

  }

  getActualAntiguedad(antuguedadEmpelado){
    debugger
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad1.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad1.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad1.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad2.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad2.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad2.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad3.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad3.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad3.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad4.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad4.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad4.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad5.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad5.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad5.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad6.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad6.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad6.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad7.split(';')[0]) 
    && antuguedadEmpelado < parseInt(this.parametersService.bonoAntiguedad7.split(';')[1]))
      return parseFloat(this.parametersService.bonoAntiguedad7.split(';')[2]);

    
    if(antuguedadEmpelado >= parseInt(this.parametersService.bonoAntiguedad8.split(';')[0]))
      return parseFloat(this.parametersService.bonoAntiguedad8.split(';')[2]);


    
  }


  changeOption(value){

  }
  cambiarTotal(value){
    this.totalGanado = this.empleado.nBonoCompensacion + this.empleado.nBasico 
                    + (this.empleado?.sSexo==="Hombre" ? this.basico.value*8*this.domingos.value/ this.parametersService.dominicalHombre : this.basico.value*8*this.domingos.value/ this.parametersService.dominicalMujer) 
                    + (this.empleado?.sSexo==="Hombre" ? this.basico.value / this.parametersService.dominicalHombre * 2 * this.horasExtras.value : this.basico.value / this.parametersService.dominicalMujer * 2 * this.horasExtras.value) 
                    + (this.empleado?.sSexo==="Hombre" ? this.basico.value / this.parametersService.dominicalHombre * 0.3 * this.horasNocturnas.value : this.basico.value / this.parametersService.dominicalMujer * 0.4 * this.horasNocturnas.value) 
                    + (this.empleado?.sSexo==="Hombre" ? this.basico.value / this.parametersService.dominicalHombre * 3 * this.horasDomingo.value : this.basico.value / this.parametersService.dominicalMujer * 4 * this.horasDomingo.value) 
                    + 1*(this.SMN * this.bonoAntiguedadActual) //ANITUGEDAD
                    + 1*(this.otros.value) + 1*(this.comisiones.value) 

    this.descuentosANS = (this.totalGanado > 13000 ? (this.totalGanado - 13000)*0.01 : 0) +  (this.totalGanado > 25000 ? (this.totalGanado - 25000)*0.05 : 0) + (this.totalGanado > 35000 ? (this.totalGanado - 35000)*0.1 : 0)
    
  }
}
