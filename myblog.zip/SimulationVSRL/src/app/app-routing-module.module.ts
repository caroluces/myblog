import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,RouterModule} from '@angular/router';
import { SimulationFormComponent } from './components/simulation-form/simulation-form.component';
import { LoginComponent } from './components/simulation-form/login/login.component';
import { MainComponent } from './components/simulation-form/main/main.component';
import { SalarioPageComponent } from './components/simulation-form/salario-page/salario-page.component';
import { PrimaComponent } from './components/simulation-form/prima/prima.component';
import { IvaComponent } from './components/simulation-form/iva/iva.component';
import { AguinaldoComponent } from './components/simulation-form/aguinaldo/aguinaldo.component';

const appRoutes:Routes=[
  {
    path:'simulator',
    component:SimulationFormComponent
  },
  {
    path:'simulatorLogin',
    component:LoginComponent
  },
  {
    path:'simulatorMain',
    component:MainComponent
  },
  {
    path:'simulatorSalarioPage',
    component:SalarioPageComponent
  },
  {
    path:'prima',
    component:PrimaComponent
  },
  {
    path:'iva',
    component:IvaComponent
  },
  {
    path:'aguinaldo',
    component:AguinaldoComponent
  },
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(appRoutes)
  ],
  exports:[RouterModule]
})
export class AppRoutingModuleModule { }
