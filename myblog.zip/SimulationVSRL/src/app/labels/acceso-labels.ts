export const accesoLabels = {
    accion: "Acción",
    fecha_hora: "Fecha y Hora",
    direccion_ip: "Dirección IP",
    navegador: "Navegador Web",
    origen: "Sistema de Origen",
}