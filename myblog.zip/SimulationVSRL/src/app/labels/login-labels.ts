export const loginLabels = {
    error_usuario_requerido: 'El usuario es requerido',
    error_contrasena_requerido: 'La contraseña es requerida',
    error_contrasena_longitud_minima: 'La contraseña debe contener mínimo 8 dígitos',
    error_contrasena_longitud_maxima: 'La contraseña debe contener mínimo 8 dígitos',
    recuerdame: 'Recuerdame',
    ingresar: 'Ingresar',
}