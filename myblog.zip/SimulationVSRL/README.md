# SimulationVSRL
App to simulate salary
